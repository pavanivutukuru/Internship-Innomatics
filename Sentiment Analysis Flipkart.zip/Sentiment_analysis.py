# =========================================================
# SENTIMENT ANALYSIS MODEL TRAINING SCRIPT
# =========================================================

# -------------------------
# 1. IMPORT LIBRARIES
# -------------------------

#import numpy as np
import pandas as pd
import re
import string
import warnings
warnings.filterwarnings("ignore")

import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, f1_score

import joblib


# -------------------------
# 2. DOWNLOAD NLTK DATA
# -------------------------

nltk.download('stopwords')
nltk.download('wordnet')


# -------------------------
# 3. LOAD DATASET
# -------------------------

df = pd.read_csv("data.csv")

df = df[['Review text', 'Ratings']]
df.dropna(inplace=True)


# -------------------------
# 4. CREATE SENTIMENT LABEL
# -------------------------

def create_sentiment(rating):
    if rating >= 4:
        return 1      # Positive
    elif rating <= 2:
        return 0      # Negative
    else:
        return np.nan # Neutral

df['sentiment'] = df['Ratings'].apply(create_sentiment)
df.dropna(inplace=True)


# -------------------------
# 5. TEXT CLEANING
# -------------------------

lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words('english'))

def clean_text(text):
    text = text.lower()
    text = text.translate(str.maketrans('', '', string.punctuation))
    text = re.sub(r'\d+', '', text)

    words = []
    for word in text.split():
        if word not in stop_words:
            words.append(lemmatizer.lemmatize(word))

    return " ".join(words)

df['cleaned_review'] = df['Review text'].apply(clean_text)


# -------------------------
# 6. FEATURES & TARGET
# -------------------------

X = df['cleaned_review']
y = df['sentiment']


# -------------------------
# 7. TRAIN-TEST SPLIT
# -------------------------

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)


# -------------------------
# 8. ML PIPELINE
# -------------------------

pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(
        max_features=5000,
        ngram_range=(1, 2)
    )),
    ('model', LogisticRegression(max_iter=1000))
])


# -------------------------
# 9. TRAIN MODEL
# -------------------------

pipeline.fit(X_train, y_train)


# -------------------------
# 10. EVALUATE MODEL
# -------------------------

y_pred = pipeline.predict(X_test)

print("Classification Report:")
print(classification_report(y_test, y_pred))

print("F1 Score:", f1_score(y_test, y_pred))


# -------------------------
# 11. SAVE MODEL
# -------------------------

joblib.dump(pipeline, "sentiment_model.pkl")


# -------------------------
# 12. TEST WITH SAMPLE INPUT
# -------------------------

samples = [
    "This shuttle quality is very bad and breaks easily",
    "Excellent product, very durable and worth the money"
]

preds = pipeline.predict(samples)

for text, pred in zip(samples, preds):
    sentiment = "Positive" if pred == 1 else "Negative"
    print(f"Review: {text}")
    print(f"Sentiment: {sentiment}")
    print("-" * 50)
