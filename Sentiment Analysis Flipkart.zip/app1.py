import streamlit as st
import joblib

# Load trained model
model = joblib.load("sentiment_model.pkl")

# App title
st.title("Flipkart Sentiment Analysis")

st.write("Enter a product review to predict sentiment")

# User input
review = st.text_area("Review Text")

if st.button("Predict Sentiment"):
    if review.strip() == "":
        st.warning("Please enter a review")
    else:
        prediction = model.predict([review])[0]

        if prediction == 1:
            st.success("Sentiment: Positive 😊")
        else:
            st.error("Sentiment: Negative 😠")
